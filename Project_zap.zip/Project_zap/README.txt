Yarin Raz - yarinraz159@gmail.com

--Amazon Project--

Looking for a specific book on Amazon, testing how much results it gives to the client, adding filter to the searching and finally checking what book has the longest name.

The project is done in Intellij app.
The project include selenium webdriver and TestNG

Get the latest update of chrome driver to run the project.

images are in png file.
