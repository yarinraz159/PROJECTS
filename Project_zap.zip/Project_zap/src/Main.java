import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver" , "C:\\chromeDriver\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.amazon.com/");
    //searching for the book
        driver.findElement(By.cssSelector("#twotabsearchtextbox")).sendKeys("Harry Potter and the Order of the Phoenix");
        driver.findElement(By.cssSelector("#nav-search-submit-text")).click();
    //printing the amount of results
        System.out.println(driver.findElement(By.cssSelector(".sg-col-inner>.a-section.a-spacing-small.a-spacing-top-small>span")).getText());
        Thread.sleep(1000);
    //adding filter to the search and printing the amount of results
        driver.findElement(By.cssSelector("[aria-label='English']>span>a>div>label>i")).click();
        System.out.println(driver.findElement(By.cssSelector(".sg-col-inner>.a-section.a-spacing-small.a-spacing-top-small>span")).getText());
    //printing the longest book name
        String name = new String();
        List<WebElement> list = driver.findElements(By.cssSelector(".a-size-medium.a-color-base.a-text-normal"));
        for (WebElement el : list) {
            if (el.getText().length() > name.length());
                name = el.getText();
        }
        System.out.println(name);
        driver.quit();
        }
}